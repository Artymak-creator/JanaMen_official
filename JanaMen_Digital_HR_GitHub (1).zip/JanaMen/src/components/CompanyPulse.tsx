import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import type { Session } from "@supabase/supabase-js";
import { BellRing, CalendarClock, CheckCircle2, Clock3, FileEdit, Filter, Megaphone, Plus, Search, Sparkles, Users, X } from "lucide-react";
import { supabase } from "../lib/supabase";
import "./CompanyPulse.css";

type Category = "important" | "schedule" | "hr_docs" | "training" | "events" | "departments";
type Importance = "normal" | "important" | "critical";
type Audience = "all" | "departments" | "groups";
type News = { id: string; title: string; body: string; category: Category; importance: Importance; author_id: string; author_name: string; published_at: string | null; effective_at: string | null; requires_ack: boolean; audience: Audience; departments: string[]; employee_groups: string[]; status: "draft" | "published"; created_at: string };
type Receipt = { news_id: string; user_id: string; acknowledged_at: string };
type Profile = { user_id: string; role: string; department?: string | null; employee_group?: string | null; display_name?: string | null };
const CATEGORIES: { id: Category | "all"; label: string }[] = [{ id: "all", label: "Все новости" }, { id: "important", label: "Важное" }, { id: "schedule", label: "График работы" }, { id: "hr_docs", label: "HR и документы" }, { id: "training", label: "Обучение" }, { id: "events", label: "Мероприятия" }, { id: "departments", label: "Новости отделов" }];
const categoryLabel: Record<Category, string> = { important: "Важное", schedule: "График работы", hr_docs: "HR и документы", training: "Обучение", events: "Мероприятия", departments: "Новости отделов" };
const importanceLabel: Record<Importance, string> = { normal: "Обычная", important: "Важно", critical: "Критично" };
const blankForm = { title: "", body: "", category: "hr_docs" as Category, importance: "normal" as Importance, effective_at: "", published_at: new Date().toISOString().slice(0, 10), requires_ack: false, audience: "all" as Audience, departments: "", employee_groups: "", status: "draft" as "draft" | "published" };
const dateLabel = (value: string | null) => value ? new Date(value).toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" }) : "Не указана";
const splitList = (s: string) => s.split(",").map(v => v.trim()).filter(Boolean);

export default function CompanyPulse({ session, role }: { session: Session; role: "employee" | "manager" | "hr" | "admin" }) {
  const [news, setNews] = useState<News[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [myReceipts, setMyReceipts] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [category, setCategory] = useState<Category | "all">("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<"newest" | "oldest">("newest");
  const [editing, setEditing] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState(blankForm);
  const [busy, setBusy] = useState(false);
  const [summary, setSummary] = useState<Record<string, string>>({});
  const [summaryBusy, setSummaryBusy] = useState<string | null>(null);
  const isHr = role === "hr" || role === "admin";

  const load = useCallback(async () => {
    setLoading(true); setError("");
    const [newsResult, profileResult, receiptResult] = await Promise.all([
      supabase.from("company_pulse_news").select("*").order("published_at", { ascending: false, nullsFirst: false }).order("created_at", { ascending: false }),
      supabase.from("profiles").select("user_id,role,department,employee_group,display_name"),
      supabase.from("company_pulse_receipts").select("news_id,user_id,acknowledged_at"),
    ]);
    if (newsResult.error) setError(newsResult.error.message.includes("company_pulse_news") || newsResult.error.code === "42P01" ? "Таблицы Company Pulse ещё не созданы. Выполните SQL-миграцию из папки supabase в архиве." : newsResult.error.message);
    else setNews((newsResult.data ?? []) as News[]);
    const allProfiles = (profileResult.data ?? []) as Profile[]; setProfiles(allProfiles);
    if (receiptResult.error && receiptResult.error.code !== "42P01") setError(current => current || receiptResult.error!.message);
    const allReceipts = (receiptResult.data ?? []) as Receipt[]; setReceipts(allReceipts);
    setMyReceipts(new Set(allReceipts.filter(r => r.user_id === session.user.id).map(r => r.news_id)));
    setLoading(false);
  }, [session.user.id]);
  useEffect(() => { void load(); }, [load]);

  const me = profiles.find(p => p.user_id === session.user.id);
  const available = useMemo(() => news.filter(n => {
    if (n.status !== "published" && !isHr) return false;
    if (!isHr && n.published_at && new Date(n.published_at).getTime() > Date.now()) return false;
    if (!isHr && n.audience === "departments" && !(me?.department && n.departments.includes(me.department))) return false;
    if (!isHr && n.audience === "groups" && !(me?.employee_group && n.employee_groups.includes(me.employee_group))) return false;
    return true;
  }), [news, isHr, editing, me?.department, me?.employee_group]);
  const filtered = useMemo(() => available.filter(n => {
    const matchesCategory = category === "all" || n.category === category || (category === "important" && n.importance !== "normal");
    const matchesText = `${n.title} ${n.body} ${n.author_name}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase());
    return matchesCategory && matchesText;
  }).sort((a, b) => {
    const da = new Date(a.published_at ?? a.created_at).getTime(), db = new Date(b.published_at ?? b.created_at).getTime();
    return sort === "newest" ? db - da : da - db;
  }), [available, category, query, sort]);

  function startCreate() { setEditing(null); setForm(blankForm); setFormOpen(true); }
  function startEdit(n: News) {
    setEditing(n.id); setForm({ title: n.title, body: n.body, category: n.category, importance: n.importance, effective_at: n.effective_at ? n.effective_at.slice(0, 10) : "", published_at: n.published_at ? n.published_at.slice(0, 10) : new Date().toISOString().slice(0, 10), requires_ack: n.requires_ack, audience: n.audience, departments: n.departments.join(", "), employee_groups: n.employee_groups.join(", "), status: n.status }); setFormOpen(true);
  }
  async function saveNews(event: FormEvent<HTMLFormElement>, publish: boolean) {
    event.preventDefault(); if (!isHr || !form.title.trim() || !form.body.trim()) return;
    setBusy(true); setError("");
    const payload = { title: form.title.trim(), body: form.body.trim(), category: form.category, importance: form.importance, author_id: session.user.id, author_name: session.user.email ?? "HR", effective_at: form.effective_at || null, requires_ack: form.requires_ack, audience: form.audience, departments: form.audience === "departments" ? splitList(form.departments) : [], employee_groups: form.audience === "groups" ? splitList(form.employee_groups) : [], status: publish ? "published" : "draft", published_at: publish ? new Date(`${form.published_at || new Date().toISOString().slice(0, 10)}T00:00:00`).toISOString() : null, updated_at: new Date().toISOString() };
    const result = editing ? await supabase.from("company_pulse_news").update(payload).eq("id", editing).select("id").maybeSingle() : await supabase.from("company_pulse_news").insert(payload).select("id").maybeSingle();
    setBusy(false);
    if (result.error) { setError(`Не удалось сохранить новость: ${result.error.message}`); return; }
    setFormOpen(false); await load();
  }
  async function acknowledge(n: News) {
    if (!n.requires_ack || myReceipts.has(n.id)) return;
    setBusy(true); setError("");
    const { data, error: e } = await supabase.from("company_pulse_receipts").upsert({ news_id: n.id, user_id: session.user.id, acknowledged_at: new Date().toISOString() }, { onConflict: "news_id,user_id" }).select("news_id,user_id,acknowledged_at").maybeSingle();
    setBusy(false); if (e) { setError(`Не удалось сохранить ознакомление: ${e.message}`); return; }
    if (data) { setMyReceipts(cur => new Set(cur).add(n.id)); setReceipts(cur => [...cur.filter(r => !(r.news_id === n.id && r.user_id === session.user.id)), data as Receipt]); }
  }
  async function makeSummary(n: News) {
    if (summary[n.id]) { setSummary(cur => { const next = { ...cur }; delete next[n.id]; return next; }); return; }
    setSummaryBusy(n.id); setError("");
    try {
      const prompt = `Сделай краткое содержание ТОЛЬКО по объявлению ниже. Не добавляй факты от себя. Если аудитория, дата действия или требуемое действие не указаны, напиши «В объявлении не указано». Ответ на русском, четыре пункта: Что изменилось; Кого касается; Когда вступает в силу; Что нужно сделать.\nЗаголовок: ${n.title}\nКатегория: ${categoryLabel[n.category]}\nОписание: ${n.body}\nДата вступления в силу: ${n.effective_at ?? "не указана"}\nАудитория: ${n.audience === "all" ? "вся компания" : n.audience === "departments" ? n.departments.join(", ") : n.employee_groups.join(", ")}`;
      const { data, error: invokeError } = await supabase.functions.invoke("gemini-assistant", { body: { messages: [{ role: "user", parts: [{ text: prompt }] }] } });
      if (invokeError || typeof data?.reply !== "string" || !data.reply.trim()) throw new Error("AI summary недоступен. Проверьте публикацию функции gemini-assistant в Supabase.");
      setSummary(cur => ({ ...cur, [n.id]: data.reply.trim() }));
    } catch (e) { setError(e instanceof Error ? e.message : "Не удалось получить краткое содержание AI."); }
    finally { setSummaryBusy(null); }
  }
  function receiptStats(n: News) {
    const target = profiles.filter(p => n.audience === "all" || (n.audience === "departments" && p.department && n.departments.includes(p.department)) || (n.audience === "groups" && p.employee_group && n.employee_groups.includes(p.employee_group)));
    const acknowledged = receipts.filter(r => r.news_id === n.id && target.some(p => p.user_id === r.user_id)).length;
    return { total: target.length, acknowledged, pending: Math.max(0, target.length - acknowledged) };
  }

  return <section className="cp-page">
    <div className="cp-hero"><div className="cp-hero-icon"><Megaphone size={25} /></div><div><span className="cp-eyebrow">JANAMEN · COMPANY PULSE</span><h2>Новости и изменения компании</h2><p>Объявления HR, обновления команд и важные изменения — в одном месте.</p></div>{isHr && <button className="primary-button cp-create" onClick={startCreate}><Plus size={17} /> Создать новость</button>}</div>
    {error && <div className="cp-error" role="alert">{error}<button type="button" onClick={() => setError("")} aria-label="Закрыть"><X size={16}/></button></div>}
    {formOpen && isHr && <div className="content-card cp-editor"><div className="section-heading"><div><h2>{editing ? "Редактирование новости" : "Новая новость"}</h2><p>Проверьте содержание и аудиторию перед публикацией.</p></div><button className="icon-button" type="button" onClick={() => setFormOpen(false)} aria-label="Закрыть"><X size={18}/></button></div>
      <form onSubmit={e => { const submitter = (e.nativeEvent as SubmitEvent).submitter as HTMLButtonElement | null; void saveNews(e, submitter?.value === "published"); }} className="cp-form"><label>Заголовок<input required maxLength={180} value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Например, обновление графика работы" /></label><label>Описание<textarea required rows={5} value={form.body} onChange={e => setForm(f => ({ ...f, body: e.target.value }))} placeholder="Что изменилось, кого касается и что нужно сделать…" /></label>
      <div className="cp-form-grid"><label>Категория<select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value as Category }))}>{CATEGORIES.filter(c => c.id !== "all").map(c => <option key={c.id} value={c.id}>{c.label}</option>)}</select></label><label>Важность<select value={form.importance} onChange={e => setForm(f => ({ ...f, importance: e.target.value as Importance }))}>{Object.entries(importanceLabel).map(([v,l]) => <option key={v} value={v}>{l}</option>)}</select></label><label>Дата публикации<input type="date" value={form.published_at} onChange={e => setForm(f => ({ ...f, published_at: e.target.value }))} /></label><label>Дата вступления в силу<input type="date" value={form.effective_at} onChange={e => setForm(f => ({ ...f, effective_at: e.target.value }))} /></label><label>Аудитория<select value={form.audience} onChange={e => setForm(f => ({ ...f, audience: e.target.value as Audience }))}><option value="all">Вся компания</option><option value="departments">Определённые отделы</option><option value="groups">Группы сотрудников</option></select></label></div>
      {form.audience === "departments" && <label>Отделы через запятую<input required value={form.departments} onChange={e => setForm(f => ({ ...f, departments: e.target.value }))} placeholder="Продажи, HR, IT" /></label>}{form.audience === "groups" && <label>Группы сотрудников через запятую<input required value={form.employee_groups} onChange={e => setForm(f => ({ ...f, employee_groups: e.target.value }))} placeholder="Руководители, Новые сотрудники" /></label>}
      <label className="cp-check"><input type="checkbox" checked={form.requires_ack} onChange={e => setForm(f => ({ ...f, requires_ack: e.target.checked }))} /> Требуется подтверждение прочтения</label>
      <div className="cp-preview"><strong>Предпросмотр</strong><span>{form.title || "Заголовок новости"}</span><p>{form.body || "Здесь будет отображаться текст объявления."}</p><small>{categoryLabel[form.category]} · {importanceLabel[form.importance]} · {form.effective_at ? `Действует с ${dateLabel(form.effective_at)}` : "Дата действия не указана"}</small></div>
      <div className="cp-actions"><button type="submit" name="saveMode" value="draft" className="secondary-button" disabled={busy}>Сохранить черновик</button><button type="submit" name="saveMode" value="published" className="primary-button" disabled={busy}>{busy ? "Сохраняем…" : "Опубликовать"}</button></div>
      </form></div>}
    <div className="cp-toolbar"><div className="cp-search"><Search size={17}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Поиск по заголовку и тексту" /></div><label className="cp-sort"><Filter size={16}/><select value={sort} onChange={e => setSort(e.target.value as "newest" | "oldest")}><option value="newest">Сначала новые</option><option value="oldest">Сначала старые</option></select></label></div>
    <div className="cp-categories">{CATEGORIES.map(c => <button key={c.id} type="button" className={category === c.id ? "selected" : ""} onClick={() => setCategory(c.id)}>{c.label}{c.id === "all" && <span>{available.length}</span>}</button>)}</div>
    {loading ? <div className="cp-empty">Загружаем новости…</div> : filtered.length === 0 ? <div className="cp-empty"><BellRing size={25}/><strong>Новостей пока нет</strong><span>{query ? "Попробуйте изменить поисковый запрос или категорию." : "Здесь появятся опубликованные объявления компании. Тестовые новости не подставляются."}</span></div> : <div className="cp-feed">{filtered.map(n => { const stats = receiptStats(n); const isNew = Date.now() - new Date(n.published_at ?? n.created_at).getTime() < 7 * 86400000; return <article className="cp-news content-card" key={n.id}><div className="cp-news-top"><span className={`cp-category cp-cat-${n.category}`}>{categoryLabel[n.category]}</span>{n.importance !== "normal" && <span className={`cp-importance cp-importance-${n.importance}`}>{n.importance === "critical" ? "Критично" : "Важно"}</span>}{n.status === "draft" && isHr && <span className="cp-category">Черновик</span>}{isNew && n.status === "published" && <span className="cp-new">Новое</span>}{n.audience !== "all" && <span className="cp-audience"><Users size={13}/>{n.audience === "departments" ? "Для отдела" : "Для группы"}</span>}</div><h3>{n.title}</h3><p className="cp-body">{n.body}</p><div className="cp-meta"><span><Clock3 size={14}/> Опубликовано: {dateLabel(n.published_at)}</span><span>Автор: {n.author_name || "HR"}</span>{n.effective_at && <span><CalendarClock size={14}/> Действует с: {dateLabel(n.effective_at)}</span>}</div>
      {n.requires_ack && <div className="cp-ack-row"><div><strong><CheckCircle2 size={16}/> Требуется подтверждение</strong>{isHr && <small>Адресовано: {stats.total} · Ознакомились: {stats.acknowledged} · Осталось: {stats.pending}</small>}</div>{myReceipts.has(n.id) ? <span className="cp-ack-done">Ознакомлен(а)</span> : <button className="primary-button" disabled={busy} onClick={() => void acknowledge(n)}>Ознакомлен</button>}</div>}
      {summary[n.id] && <div className="cp-summary"><strong><Sparkles size={16}/> Краткое содержание AI</strong><p>{summary[n.id]}</p></div>}<div className="cp-card-actions"><button type="button" className="secondary-button" disabled={summaryBusy === n.id} onClick={() => void makeSummary(n)}><Sparkles size={15}/>{summaryBusy === n.id ? "Готовим…" : summary[n.id] ? "Скрыть AI summary" : "Краткое содержание AI"}</button>{isHr && <button type="button" className="secondary-button" onClick={() => startEdit(n)}><FileEdit size={15}/> Редактировать</button>}</div>
      </article>; })}</div>}
    {isHr && <section className="cp-admin-note"><Users size={18}/><div><strong>Контроль ознакомления</strong><p>Счётчики показывают количество профилей, подходящих под аудиторию объявления. Для точной адресации отделам и группам заполните поля department и employee_group в профилях сотрудников.</p></div></section>}
  </section>;
}
