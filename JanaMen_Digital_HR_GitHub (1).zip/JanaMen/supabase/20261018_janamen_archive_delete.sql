-- JanaМен: архив и безопасное удаление завершённых заявок.
-- Запустить один раз в Supabase SQL Editor ПОСЛЕ основной схемы.
-- Сначала сделай резервную копию базы. Эта миграция не удаляет существующие заявки.

ALTER TABLE public.requests
  ADD COLUMN IF NOT EXISTS archived_at timestamptz NULL;

CREATE INDEX IF NOT EXISTS requests_archived_at_idx
  ON public.requests (archived_at);

COMMENT ON COLUMN public.requests.archived_at IS
  'NULL — активная заявка; timestamp — заявка помещена в архив.';

CREATE OR REPLACE FUNCTION public.janamen_guard_request_workflow()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_requester_role text;
  v_actor_role text;
  v_reporting_manager_id uuid;
  v_manager_role text;
  v_balance integer;
  v_days integer;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF auth.uid() IS NULL OR NEW.user_id IS DISTINCT FROM auth.uid() THEN
      RAISE EXCEPTION 'Нельзя создавать заявку от имени другого пользователя';
    END IF;

    SELECT p.role::text, p.manager_id
      INTO v_requester_role, v_reporting_manager_id
    FROM public.profiles p
    WHERE p.user_id = NEW.user_id;

    IF v_requester_role IS NULL OR v_requester_role NOT IN ('employee', 'manager') THEN
      RAISE EXCEPTION 'Создавать заявки могут только сотрудник и руководитель';
    END IF;

    IF v_requester_role = 'employee' AND v_reporting_manager_id IS NULL THEN
      RAISE EXCEPTION 'Сотруднику не назначен руководитель: заполните profiles.manager_id';
    END IF;

    IF v_reporting_manager_id IS NOT NULL THEN
      SELECT p.role::text INTO v_manager_role
      FROM public.profiles p
      WHERE p.user_id = v_reporting_manager_id;
      IF v_manager_role IS DISTINCT FROM 'manager' THEN
        RAISE EXCEPTION 'Назначенный согласующий должен иметь роль manager';
      END IF;
    END IF;

    NEW.approver_manager_id := v_reporting_manager_id;
    NEW.status := 'На рассмотрении';
    NEW.workflow_stage := CASE WHEN v_reporting_manager_id IS NULL THEN 'hr' ELSE 'manager' END;
    NEW.manager_comment := '';
    NEW.manager_reviewed_by := NULL;
    NEW.manager_reviewed_at := NULL;
    NEW.hr_comment := '';
    NEW.hr_signed_by := NULL;
    NEW.hr_signed_at := NULL;

    IF NEW.request_type = 'Ежегодный отпуск' THEN
      IF NEW.start_date IS NULL OR NEW.end_date IS NULL OR NEW.end_date < NEW.start_date THEN
        RAISE EXCEPTION 'Для отпуска укажите корректные даты начала и окончания';
      END IF;
      IF NEW.leave_type NOT IN ('paid', 'unpaid') THEN
        RAISE EXCEPTION 'Выберите тип отпуска: оплачиваемый или без содержания';
      END IF;

      v_days := (NEW.end_date - NEW.start_date) + 1;
      NEW.leave_days_requested := v_days;

      IF NEW.leave_type = 'paid' THEN
        SELECT p.annual_leave_days_remaining INTO v_balance
        FROM public.profiles p
        WHERE p.user_id = NEW.user_id
        FOR UPDATE;

        IF v_balance IS NULL THEN
          RAISE EXCEPTION 'Остаток оплачиваемых дней не задан в профиле сотрудника';
        END IF;
        IF v_balance < v_days THEN
          RAISE EXCEPTION 'Недостаточно оплачиваемых дней: доступно %, запрошено %', v_balance, v_days;
        END IF;
        NEW.leave_balance_at_submission := v_balance;
      ELSE
        NEW.leave_balance_at_submission := NULL;
      END IF;
    ELSE
      NEW.leave_type := NULL;
      NEW.leave_days_requested := NULL;
      NEW.leave_balance_at_submission := NULL;
    END IF;

    RETURN NEW;
  END IF;

  SELECT p.role::text INTO v_actor_role
  FROM public.profiles p
  WHERE p.user_id = auth.uid();


  -- Archive-only update for completed requests. No workflow fields may change.
  IF NEW.archived_at IS DISTINCT FROM OLD.archived_at THEN
    IF (to_jsonb(NEW) - ARRAY['archived_at','updated_at'])
       IS DISTINCT FROM
       (to_jsonb(OLD) - ARRAY['archived_at','updated_at']) THEN
      RAISE EXCEPTION 'При архивации нельзя менять поля заявки';
    END IF;

    IF OLD.status NOT IN ('Одобрена', 'Отклонена') OR OLD.workflow_stage <> 'done' THEN
      RAISE EXCEPTION 'Архивировать можно только завершённые заявки';
    END IF;

    IF NOT COALESCE((
      (v_actor_role = 'employee' AND OLD.user_id = auth.uid())
      OR (v_actor_role = 'manager' AND (OLD.user_id = auth.uid() OR OLD.approver_manager_id = auth.uid()))
      OR (v_actor_role = 'hr' AND OLD.workflow_stage <> 'manager')
    ), FALSE) THEN
      RAISE EXCEPTION 'Нет прав на архивацию этой заявки';
    END IF;

    RETURN NEW;
  END IF;

  IF OLD.status <> 'На рассмотрении' THEN
    RAISE EXCEPTION 'Заявка уже завершена и не может быть изменена';
  END IF;

  -- Manager stage: approve and forward to HR, or reject.
  IF OLD.workflow_stage = 'manager'
     AND v_actor_role = 'manager'
     AND OLD.approver_manager_id = auth.uid() THEN
    IF (to_jsonb(NEW) - ARRAY['status','workflow_stage','manager_comment','manager_reviewed_by','manager_reviewed_at','updated_at'])
       IS DISTINCT FROM
       (to_jsonb(OLD) - ARRAY['status','workflow_stage','manager_comment','manager_reviewed_by','manager_reviewed_at','updated_at']) THEN
      RAISE EXCEPTION 'Руководитель может изменить только решение и комментарий своего этапа';
    END IF;

    IF NEW.status = 'На рассмотрении' THEN
      NEW.workflow_stage := 'hr';
    ELSIF NEW.status = 'Отклонена' THEN
      NEW.workflow_stage := 'done';
    ELSE
      RAISE EXCEPTION 'На этапе руководителя можно согласовать или отклонить заявку';
    END IF;

    NEW.manager_reviewed_by := auth.uid();
    NEW.manager_reviewed_at := now();
    RETURN NEW;
  END IF;

  -- Final HR stage: sign the result and deduct approved paid leave atomically.
  IF OLD.workflow_stage = 'hr'
     AND v_actor_role = 'hr' THEN
    IF (to_jsonb(NEW) - ARRAY['status','workflow_stage','hr_comment','hr_signed_by','hr_signed_at','updated_at'])
       IS DISTINCT FROM
       (to_jsonb(OLD) - ARRAY['status','workflow_stage','hr_comment','hr_signed_by','hr_signed_at','updated_at']) THEN
      RAISE EXCEPTION 'HR может изменить только итоговое решение и комментарий HR';
    END IF;

    IF NEW.status NOT IN ('Одобрена', 'Отклонена') THEN
      RAISE EXCEPTION 'HR должен одобрить или отклонить заявку';
    END IF;

    NEW.workflow_stage := 'done';
    NEW.hr_signed_by := COALESCE(auth.jwt() ->> 'email', auth.uid()::text);
    NEW.hr_signed_at := now();

    IF NEW.status = 'Одобрена'
       AND OLD.request_type = 'Ежегодный отпуск'
       AND OLD.leave_type = 'paid' THEN
      UPDATE public.profiles
      SET annual_leave_days_remaining = annual_leave_days_remaining - OLD.leave_days_requested
      WHERE user_id = OLD.user_id
        AND annual_leave_days_remaining IS NOT NULL
        AND annual_leave_days_remaining >= OLD.leave_days_requested;
      IF NOT FOUND THEN
        RAISE EXCEPTION 'Не удалось списать оплачиваемые дни: проверьте остаток дней сотрудника';
      END IF;
    END IF;

    RETURN NEW;
  END IF;

  RAISE EXCEPTION 'У пользователя нет прав на этот этап согласования';
END;
$$;

-- Разрешаем архивировать только завершённые заявки в рамках существующей видимости ролей.
DROP POLICY IF EXISTS janamen_requests_archive_update ON public.requests;
CREATE POLICY janamen_requests_archive_update ON public.requests
FOR UPDATE TO authenticated
USING (
  status IN ('Одобрена', 'Отклонена')
  AND workflow_stage = 'done'
  AND (
    user_id = auth.uid()
    OR approver_manager_id = auth.uid()
    OR (public.janamen_current_role() = 'hr' AND workflow_stage <> 'manager')
  )
)
WITH CHECK (
  status IN ('Одобрена', 'Отклонена')
  AND workflow_stage = 'done'
  AND (
    user_id = auth.uid()
    OR approver_manager_id = auth.uid()
    OR (public.janamen_current_role() = 'hr' AND workflow_stage <> 'manager')
  )
);

-- Удаление через защищённую RPC-функцию: прямой DELETE из браузера не разрешаем.
CREATE OR REPLACE FUNCTION public.janamen_delete_completed_request(p_request_id text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_actor_role text;
  v_owner_id uuid;
  v_status text;
  v_stage text;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Требуется авторизация';
  END IF;

  v_actor_role := public.janamen_current_role();
  IF v_actor_role IS NULL OR v_actor_role NOT IN ('employee', 'manager', 'hr') THEN
    RAISE EXCEPTION 'Нет прав на удаление заявок';
  END IF;

  SELECT r.user_id, r.status, r.workflow_stage
    INTO v_owner_id, v_status, v_stage
  FROM public.requests r
  WHERE r.id::text = p_request_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Заявка не найдена';
  END IF;

  IF v_status NOT IN ('Одобрена', 'Отклонена') OR v_stage <> 'done' THEN
    RAISE EXCEPTION 'Удалять можно только завершённые заявки';
  END IF;

  IF v_actor_role <> 'hr' AND v_owner_id <> auth.uid() THEN
    RAISE EXCEPTION 'Можно удалять только собственные завершённые заявки';
  END IF;

  DELETE FROM public.request_history WHERE request_id = p_request_id;
  DELETE FROM public.requests WHERE id::text = p_request_id;
END;
$$;

REVOKE ALL ON FUNCTION public.janamen_delete_completed_request(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.janamen_delete_completed_request(text) FROM anon;
GRANT EXECUTE ON FUNCTION public.janamen_delete_completed_request(text) TO authenticated;
