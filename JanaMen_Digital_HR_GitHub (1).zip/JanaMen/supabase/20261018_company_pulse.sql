-- JanaМен Company Pulse. Safe additive migration for an EXISTING project.
-- Run once in Supabase SQL Editor after backing up the project.
-- Does not alter requests, approval triggers, or request RLS policies.

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS department text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS employee_group text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS display_name text;

CREATE TABLE IF NOT EXISTS public.company_pulse_news (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL CHECK (length(trim(title)) BETWEEN 1 AND 180),
  body text NOT NULL CHECK (length(trim(body)) BETWEEN 1 AND 12000),
  category text NOT NULL CHECK (category IN ('important','schedule','hr_docs','training','events','departments')),
  importance text NOT NULL DEFAULT 'normal' CHECK (importance IN ('normal','important','critical')),
  author_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE RESTRICT,
  author_name text NOT NULL DEFAULT 'HR',
  published_at timestamptz,
  effective_at date,
  requires_ack boolean NOT NULL DEFAULT false,
  audience text NOT NULL DEFAULT 'all' CHECK (audience IN ('all','departments','groups')),
  departments text[] NOT NULL DEFAULT ARRAY[]::text[],
  employee_groups text[] NOT NULL DEFAULT ARRAY[]::text[],
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (audience <> 'departments' OR cardinality(departments) > 0),
  CHECK (audience <> 'groups' OR cardinality(employee_groups) > 0)
);
CREATE INDEX IF NOT EXISTS company_pulse_news_published_idx ON public.company_pulse_news (published_at DESC) WHERE status = 'published';
CREATE INDEX IF NOT EXISTS company_pulse_news_category_idx ON public.company_pulse_news (category, published_at DESC);

CREATE TABLE IF NOT EXISTS public.company_pulse_receipts (
  news_id uuid NOT NULL REFERENCES public.company_pulse_news(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  acknowledged_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (news_id, user_id)
);
CREATE INDEX IF NOT EXISTS company_pulse_receipts_user_idx ON public.company_pulse_receipts (user_id, news_id);

ALTER TABLE public.company_pulse_news ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.company_pulse_receipts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS company_pulse_news_read ON public.company_pulse_news;
CREATE POLICY company_pulse_news_read ON public.company_pulse_news
FOR SELECT TO authenticated
USING (
  (status = 'published' AND (published_at IS NULL OR published_at <= now()) AND (
    audience = 'all'
    OR (audience = 'departments' AND EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.user_id = auth.uid() AND p.department = ANY(company_pulse_news.departments)
    ))
    OR (audience = 'groups' AND EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.user_id = auth.uid() AND p.employee_group = ANY(company_pulse_news.employee_groups)
    ))
  ))
  OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid() AND p.role IN ('hr','admin'))
);

DROP POLICY IF EXISTS company_pulse_news_hr_insert ON public.company_pulse_news;
CREATE POLICY company_pulse_news_hr_insert ON public.company_pulse_news
FOR INSERT TO authenticated
WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid() AND p.role IN ('hr','admin')));
DROP POLICY IF EXISTS company_pulse_news_hr_update ON public.company_pulse_news;
CREATE POLICY company_pulse_news_hr_update ON public.company_pulse_news
FOR UPDATE TO authenticated
USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid() AND p.role IN ('hr','admin')))
WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid() AND p.role IN ('hr','admin')));
DROP POLICY IF EXISTS company_pulse_news_hr_delete ON public.company_pulse_news;
CREATE POLICY company_pulse_news_hr_delete ON public.company_pulse_news
FOR DELETE TO authenticated
USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid() AND p.role IN ('hr','admin')));

DROP POLICY IF EXISTS company_pulse_receipts_read ON public.company_pulse_receipts;
CREATE POLICY company_pulse_receipts_read ON public.company_pulse_receipts
FOR SELECT TO authenticated
USING (
  user_id = auth.uid()
  OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid() AND p.role IN ('hr','admin'))
);
DROP POLICY IF EXISTS company_pulse_receipts_insert ON public.company_pulse_receipts;
CREATE POLICY company_pulse_receipts_insert ON public.company_pulse_receipts
FOR INSERT TO authenticated
WITH CHECK (
  user_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.company_pulse_news n
    WHERE n.id = news_id AND n.status = 'published' AND (n.published_at IS NULL OR n.published_at <= now()) AND n.requires_ack = true
      AND (
        n.audience = 'all'
        OR (n.audience = 'departments' AND EXISTS (
          SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid() AND p.department = ANY(n.departments)
        ))
        OR (n.audience = 'groups' AND EXISTS (
          SELECT 1 FROM public.profiles p WHERE p.user_id = auth.uid() AND p.employee_group = ANY(n.employee_groups)
        ))
      )
  )
);
DROP POLICY IF EXISTS company_pulse_receipts_update ON public.company_pulse_receipts;
CREATE POLICY company_pulse_receipts_update ON public.company_pulse_receipts
FOR UPDATE TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

GRANT SELECT, INSERT, UPDATE, DELETE ON public.company_pulse_news TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.company_pulse_receipts TO authenticated;

-- Extend supported role list to include admin for Company Pulse administration.
-- Existing role values and profiles are preserved.
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_role_check;
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profile_role_check;
ALTER TABLE public.profiles ADD CONSTRAINT profiles_role_check CHECK (role IN ('employee','manager','hr','admin'));
